#!/usr/bin/env python

import sys

(last_key, min_val, max_val, count) = (None, sys.float_info.max, -sys.float_info.max, 0)
for line in sys.stdin:
  (key, val) = line.strip().split("\t")
  if last_key and last_key != key:
    print "%s\t%s\t%s\t%s" % (last_key, 1.8*min_val/float(10)+32, 1.8*max_val/float(10)+32, count)
    (last_key, min_val, max_val, count) = (key, float(val), float(val), 1)
  else:
    (last_key, min_val, max_val, count) = (key, min(min_val, float(val)), max(max_val, float(val)), count+1)

if last_key:
  print "%s\t%s\t%s\t%s" % (last_key, 1.8*min_val/float(10)+32, 1.8*max_val/float(10)+32, count)
