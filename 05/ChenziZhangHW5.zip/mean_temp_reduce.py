#!/usr/bin/env python

import sys

(last_key, tempsum, count) = (None, 0, 0)
for line in sys.stdin:
  (key, val) = line.strip().split("\t")
  if last_key and last_key != key:
    print "%s\t%s" % (last_key, tempsum/max(count,1)/float(10))
    (last_key, tempsum, count) = (key, float(val), 1)
  else:
    (last_key, tempsum, count) = (key, tempsum + float(val), count + 1)

if last_key:
  print "%s\t%s" % (last_key, tempsum/max(count,1)/float(10))
