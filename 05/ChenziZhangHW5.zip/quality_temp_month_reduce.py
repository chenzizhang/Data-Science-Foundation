#!/usr/bin/env python

import sys

(last_key, tempcount, validcount) = (None, 0, 0)
for line in sys.stdin:
  (key, tempc, validc) = line.strip().split("\t")
  if last_key and last_key != key:
    print "%s\t%s\t%s" % (last_key, tempcount, validcount)
    (last_key, tempcount, validcount) = (key, int(tempc), int(validc))
  else:
    (last_key, tempcount, validcount) = (key, tempcount + int(tempc), validcount + int(validc))

if last_key:
  print "%s\t%s\t%s" % (last_key, tempcount, validcount)
